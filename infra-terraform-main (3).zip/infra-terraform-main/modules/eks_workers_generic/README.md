# eks_workers

This module creates an ASG of worker nodes for a eks controlplane cluster. It depends on security groups and eks cluster created by eks_controlplane module
